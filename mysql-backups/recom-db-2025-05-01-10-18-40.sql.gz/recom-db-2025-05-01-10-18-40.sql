-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: laravel-db    Database: recom_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_secret` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token` text COLLATE utf8mb4_unicode_ci,
  `api_status` tinyint unsigned DEFAULT NULL COMMENT '1 = Working, 2 = Error',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `token_updated` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cron_logs`
--

DROP TABLE IF EXISTS `cron_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cron_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Command Name',
  `arguments` json DEFAULT NULL COMMENT 'Command Arguments|Paremeters',
  `error_msg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1','2') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '0 = Pending, 1 = Success, 2 = Error',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron_logs`
--

LOCK TABLES `cron_logs` WRITE;
/*!40000 ALTER TABLE `cron_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cron_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_03_12_060759_create_accounts_table',1),(5,'2025_03_17_044741_create_transparency_product_files_table',1),(6,'2025_03_18_050402_create_product_lists_table',1),(7,'2025_03_24_095248_create_transparency_gtin_code_histories_table',1),(8,'2025_04_09_101000_create_cron_logs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_lists`
--

DROP TABLE IF EXISTS `product_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_lists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `account_config_id` bigint unsigned NOT NULL,
  `product_file_id` bigint unsigned NOT NULL COMMENT 'Primary Key of transparency_product_files table',
  `brand` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gtin` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_lists_sku_unique` (`sku`),
  KEY `product_lists_account_config_id_foreign` (`account_config_id`),
  KEY `product_lists_product_file_id_foreign` (`product_file_id`),
  CONSTRAINT `product_lists_account_config_id_foreign` FOREIGN KEY (`account_config_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `product_lists_product_file_id_foreign` FOREIGN KEY (`product_file_id`) REFERENCES `transparency_product_files` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_lists`
--

LOCK TABLES `product_lists` WRITE;
/*!40000 ALTER TABLE `product_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('0DG9LFumy0ZeaVY234yg56oyjPnnHKx04YVwq1t7',NULL,'134.19.179.147','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_17) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Safari/605.1.15','YTozOntzOjY6Il90b2tlbiI7czo0MDoib1I1R21LVXF3em5UdDBUbzFWNmpxSzZDUll5eEdHTWt3bjU2NlU0MyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745976998),('0gzulBHmHS57xIMKUAfvAMUGoqpR7FRtbW8CKhJ2',NULL,'104.131.89.40','Mozilla/5.0 (compatible)','YTozOntzOjY6Il90b2tlbiI7czo0MDoic0FTRTRGeGFUdXdSWUhNZlRiTkZRZ1o5aDJ4QjkzT241dDhzd2piciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746058574),('0Uws3ckbqtjAtQQlxPec43bkkow2KovkQFTAdEMB',NULL,'132.145.42.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3','YTozOntzOjY6Il90b2tlbiI7czo0MDoidlVTMVI4bDQwVnpJWmNvR2w5MFlIWGgwcXNlcWl5NnFrU1BPVzZYaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTQ6Imh0dHBzOi8vZWMyLTMtMjMxLTU2LTE0Ny5jb21wdXRlLTEuYW1hem9uYXdzLmNvbS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746020488),('1BgRfits3plofNVWQr1xTIwPESvrT4fkFoxKG21S',NULL,'104.234.115.168','\'Mozilla/5.0 (compatible; GenomeCrawlerd/1.0; +https://www.nokia.com/genomecrawler)\'','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWU9EZHpmNGtqZ1pHS2JrdGtHbnFDelpHbzFzQm9zd1hmeWNCYVhvZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746073297),('1QzwTU7eLGMPp2SVgYbvDm2iM0POVvEZvgL78v2w',NULL,'147.185.132.12','Expanse, a Palo Alto Networks company, searches across the global IPv4 space multiple times per day to identify customers&#39; presences on the Internet. If you would like to be excluded from our scans, please send IP addresses/domains to: scaninfo@paloaltonetworks.com','YTozOntzOjY6Il90b2tlbiI7czo0MDoibE9vTFlBM2c0Z1ExQVRrZEdPcW1lVFFsS2YyYkxzaEFvWW1YclZtVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745980339),('25WXYAMyOkkXRbSBeFh9dbeXNHvhSAhVtwj6kPs3',NULL,'35.82.31.94','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.26 Safari/537.36 Core/1.63.5977.400 LBBROWSER/10.1.3752.400','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTkhEUk1DTGdYRXYzUWdPc3dRWWxVd3hrdm93U2lueWh5cmJ6RVExTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746014378),('2f1QZQy1d4TqL7mXwSc7Jy2OWp4clbtSZoQThgEX',NULL,'118.194.228.167','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOFI4NUh1ZG13aVN1dGVtMkc4UjJ0QjZwdUdqSWl0VVVhdXZtNmNNTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746037196),('2ozErmMy3Vbr5Cg9VK4LBMMnO9Nmn2q84LuUiqTl',NULL,'87.236.176.154','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRUZqZmZSWFVzUWg5QVFiSmhIa1ZiajJ4b1dob2JES0xXOTh2YXczRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDI6Imh0dHBzOi8vcmVjb20ucHJhc2hhbnQtZGV2b3BzLm9ubGluZS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746014776),('2ZvVgsSO0DTalbzTc0uiqkmtvL7wxaWcjcjCGp0q',NULL,'185.247.137.229','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoib0gzUUZ0SENHc2VIUm1kT0FIdDl5akFPeGZIYXRnNEtWdWVTR25PWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746021558),('4O4b450vU1iwkEv8F98Gfrn6cbItA50AbfEb6zmr',NULL,'104.234.115.168','\'Mozilla/5.0 (compatible; GenomeCrawlerd/1.0; +https://www.nokia.com/genomecrawler)\'','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWUNuMlFubXZRVjM5ZHhUeEptVjZmallEeXZKdXNTbGlqMDZmRUdOYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746073682),('56aVelGXTTUixoTClEmWe0kH3seDXcrbFUA8lwQB',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNktkYVlOSWV0NWg2UGc5dDlsVjRFbzl1cVZ0ZXF0UG1OUWFXSFBkSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746060235),('5ejbeVPGUuzYxUsjbzlZuwZltFIDZcI5xktdk1Lt',NULL,'35.82.31.94','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.105 Safari/537.36 Vivaldi/1.0.162.9','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVTBkOFBqd2NsUVU2djJxSU5uMEJUNjJOTU94b1ZEWlRYSk1wWVI5WCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746087989),('6DjjOAXZhiKXvQOL3eV3DmqxnU9FOAv0xN4suGtD',NULL,'8.209.96.179','Go-http-client/1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVHNCbTNDNkZUSG5vRmhlOEhpN0ZWSjdVc244eE41bnNralZGYVI5UiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjU6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Lz9kbnM9WlFrQkFBQUJBQUFBQUFBQUIyVjRZVzF3YkdVRFkyOXRBQUFCQUFFIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745991681),('6DJu4yQLueMwazpdAz9ThMJWUiq5kERLQ2vW9eMx',NULL,'20.203.40.116','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOThiZjRCbDV6cU1CRDhaMGdsUUJPWkRSSHFHWHBJblpnekxWcWVONiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745984576),('6R69rtgO38ALUv20bNmXwoHiwj6YD77YEdKasWf4',NULL,'43.240.223.15','Custom-AsyncHttpClient','YTozOntzOjY6Il90b2tlbiI7czo0MDoidVpmeUdPVW1vaUV6WnAzSmdmWFBEcXlEUkZ6ampFN1I1SEZ4NnplWCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk5OiJodHRwczovLzMuMjMxLjU2LjE0Ny9pbmRleC5waHA/JTJGJTNDJTNGZWNobyUyOG1kNSUyOCUyMmhpJTIyJTI5JTI5JTNCJTNGJTNFJTIwJTJGdG1wJTJGaW5kZXgxLnBocD0mY29uZmlnLWNyZWF0ZSUyMCUyRj0mbGFuZz0uLiUyRi4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRi4uJTJGdXNyJTJGbG9jYWwlMkZsaWIlMkZwaHAlMkZwZWFyY21kIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746085933),('9KjF4JjxKSlDxiym2p5O8kcLLQvpYS2pefSegMTH',NULL,'206.168.34.195','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoieE9xQ01HTEdRVmtLSGVRWXF3Z0ZETjFXaTRwbFNDTEJMWld5SEJmbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746002724),('9mxSoYyuwSeakFPr1H85KF0Mt6T0AVvn6aqpD3v9',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUk5tZUJiamZmWU91N215RHRZNUtjbEd0c3NsS3ZZRFVQZzJMeTFTaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746060236),('9WOD3jEVbqzu9argEghnZPsNHnfUbhdTk0vTFLZH',NULL,'198.235.24.54','Expanse, a Palo Alto Networks company, searches across the global IPv4 space multiple times per day to identify customers&#39; presences on the Internet. If you would like to be excluded from our scans, please send IP addresses/domains to: scaninfo@paloaltonetworks.com','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNEVZQ2xGbnpkNEFMVXoyOVlpbmVQT2RIQkc0NlVVUHFnMldOQzBPOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745946280),('A2w145WZXcYc5AF2hqZqZBy83miMOv0YmdqC18LX',NULL,'101.198.0.152','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNmk1SExOUGh4cVJtaGNGSG1HVjdMMHhGajFHQ1RkR01rcmE2NHlZZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHBzOi8vZWMyLTMtMjMxLTU2LTE0Ny5jb21wdXRlLTEuYW1hem9uYXdzLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746047994),('b1cEAYwFWV19TtZKwcpimNUpTuE0D75P6FSnKz4P',NULL,'209.126.83.235','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1.2 Safari/605.1.15','YTozOntzOjY6Il90b2tlbiI7czo0MDoibVFLak1keFE4TXl2Qk1XaWZPZHJ3bmc4R3Y2eEFKRTNnRzNGQzVhZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746073554),('bF2fLDi31OeDgJDIRF8xfcVppwSDEQTIuU8kOliq',NULL,'206.168.34.88','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoia0F0UXdua3ZHMjFtQmJ2dW5EbjBkN2lRMGdycGt3RlQ4R3FjcTY4ZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745994717),('BkVPWMUr9sNGqtZxg94ExcU2sUyDQPc88rOQvZ4L',NULL,'35.82.31.94','Mozilla/5.0 (Linux; Android 9; vivo 1805) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.101 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNjc4OGFnNWRqR01JQzZYbFhQSlczY1prTVN5MzAyTWRGNWRXRkFOaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745943712),('bLL2oLOuObe27HXwEly7CfVk8KYXC9wNbt9B7J3E',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoibEpRekc1eGZkU1VPUVJZeXpKM2lDY0lob2w0azdWc2c4NGdOOFM5TyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746061423),('c7S1D95jpmBihVoLmcsGXshFZlNHCeXyUPvwSBOo',NULL,'87.236.176.154','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSGxLRGRmSWl0cmkwcW16UjR1UnhRempadDFJODJnYkJpRVM5Z2FONCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vcmVjb20ucHJhc2hhbnQtZGV2b3BzLm9ubGluZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746014775),('cKbcDwRQtHNAXMA4IPwBE6swe7iJEclTxH67klmk',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoicXZKU3JnUHdGaG1iV1d6SVo5SHB2Q3BaM0tDMHpoWEpwNHFGaUtGWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTE6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Lz9YREVCVUdfU0VTU0lPTl9TVEFSVD1waHBzdG9ybSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746057192),('CWiNFBz9JKQQU4XC3ETMUCQ78mZ0Gdq3st7eqo9C',NULL,'46.105.81.71','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoidU5ETjZDelByZFNzRW1lOWdaY0tZVktPbVdkMklTZWQ3WUtuZXBlOCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746060905),('DPE7gtxi67FhjFnSO5MfVxoS0X5XJ7YyErxAgnIm',NULL,'122.164.127.123','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:136.0) Gecko/20100101 Firefox/136.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoieER5eHNZM1k2S2tjbGw3QVp1Q1BiTFZ2R1F1NFNvV3Nib2NpcnRENiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDI6Imh0dHBzOi8vcmVjb20ucHJhc2hhbnQtZGV2b3BzLm9ubGluZS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746090172),('dqTHcn9F1ByV5n3J2QfoHqEkYWDk0VyWSAjOG4tL',NULL,'206.168.34.195','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoieldlNElXZ3FIVjlZNDhraEpiSVhYQnMzVXM4NUVPODNrTzlDSW84biI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746002751),('eCB62R7TmxOJwnxxzN2qqk2WDFq9K8rIIumqzFSg',NULL,'147.185.132.12','Expanse, a Palo Alto Networks company, searches across the global IPv4 space multiple times per day to identify customers&#39; presences on the Internet. If you would like to be excluded from our scans, please send IP addresses/domains to: scaninfo@paloaltonetworks.com','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWVZsRzl5THJ6SFJRNWpEcGxySVNmVEhhM3kzaUxvdkttSE05dENsRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745980340),('EDYKyoiBaX57nI4GGD5kO2EuFhZGr04gV9a4Bxez',NULL,'23.27.145.87','Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoicUlwWkpOaU1vZ2xBZDQzUURqTEZ4NDNkYkg4TWlqeGtKcGYxQmFsOCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDI6Imh0dHBzOi8vcmVjb20ucHJhc2hhbnQtZGV2b3BzLm9ubGluZS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1745962439),('Ekj3Cjh3LqqZFkqawY0qmBq59OtvvT6Nl65s0cfM',NULL,'101.198.0.187','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11','YTozOntzOjY6Il90b2tlbiI7czo0MDoiY0ZwRnBaM3JIR1lRU3lmU3FZdDRpYW1LSnQ1OGI1RHRLUXZrdTFvbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTQ6Imh0dHBzOi8vZWMyLTMtMjMxLTU2LTE0Ny5jb21wdXRlLTEuYW1hem9uYXdzLmNvbS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746048073),('fDOKBWgjJcs1JdweahRbKPcx2zLzfOlW1ExYSfpe',NULL,'104.131.89.40','Mozilla/5.0 (compatible)','YTozOntzOjY6Il90b2tlbiI7czo0MDoib3djc3o0VUd2YzJuOEhyS1lGUEl4d2IwYVV3ZTdYczdrNGtuZ0lRVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746058574),('gkz1e2eyX0erLcHDgJN9MUjjkfvg1NKstiULkL1e',NULL,'8.209.96.179','Go-http-client/1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ3paRlNKSnlWT0RBV2RIUG9Db3Y2OGczcUdYZUhqSTBVZWgycGF1ZiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Lz9uYW1lPWV4YW1wbGUuY29tJnR5cGU9QSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1745991682),('h2IiGzYkQom6owk8SmMJoeAQBXeICryv0E2n7zqX',NULL,'118.194.228.167','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaXBjdnphS1pjRzVzZWFtTE8zaGd3Tk5pYjQ5dmRjc1kyN09pRzdpUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746037195),('hQgttd65ozE6zWL3viM9bkTs0Wl8ab2duTsl312Z',NULL,'101.198.0.151','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYVlQWnRnQXBVbTlsSkVmQ1lTME5GRzZoWWRSdXQ1OUc4RHY0NElLdyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHBzOi8vZWMyLTMtMjMxLTU2LTE0Ny5jb21wdXRlLTEuYW1hem9uYXdzLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746048072),('i4tamWuqZ9iK3GK6WTzdzt5zJgxHuJwNFUVrwmGi',NULL,'101.198.0.150','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11','YTozOntzOjY6Il90b2tlbiI7czo0MDoiR2dUdGxLc2R5emNkekc0OFd0RE1EUTZqdDNhNzJhdnJXaWJKeXhqaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTQ6Imh0dHBzOi8vZWMyLTMtMjMxLTU2LTE0Ny5jb21wdXRlLTEuYW1hem9uYXdzLmNvbS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746048014),('iTrqdW08rxeT1BbIUyoYeF88KKYGXd5IwjV9qPAf',NULL,'43.240.223.15','Custom-AsyncHttpClient','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNG1iTGNEVWRWVHhyRkZzbjhUZnpHdDFnSW8zZDdrNEg1WUw2WjJRQiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTQ2OiJodHRwczovLzMuMjMxLjU2LjE0Ny9pbmRleC5waHA/ZnVuY3Rpb249Y2FsbF91c2VyX2Z1bmNfYXJyYXkmcz0lMkZpbmRleCUyRiU1Q3RoaW5rJTVDYXBwJTJGaW52b2tlZnVuY3Rpb24mdmFycyU1QjAlNUQ9bWQ1JnZhcnMlNUIxJTVEJTVCMCU1RD1IZWxsbyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746085930),('iUYVOQVPLnshNh1nuQB7JOf04ODRe5SZwjPQ4pYU',NULL,'46.105.81.71','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVVNjYU1DdWltSDlHVzhrZEhrb2NSMzFFVUFMRDlia3dFUXJ1cVJaMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746060906),('IY9AaOa0yzEooO2bFOawXmdhYmf9jZm0ER2GxA1F',NULL,'122.164.127.123','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQnNSUDNIR3FxaEgwMFkxa29yVW9MckFHbDNpTlA3VkhEUXA1UjNmYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDI6Imh0dHBzOi8vcmVjb20ucHJhc2hhbnQtZGV2b3BzLm9ubGluZS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746094335),('j4c4nh5fnMGR09SFdshO2Sm4URjYm1hoBhmwdEAo',NULL,'206.168.34.210','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWHBIdEZNYmFvNmZIYlFNWHhwWHFXRnhpVEtRcGxGRkNJUTlBdnpjbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746069808),('J5iFNQZ52lf6ek91GIq8mWna7jqGpBMv8ecNIG2w',NULL,'101.36.108.158','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/538.46 (KHTML, like Gecko) Chrome/88.0.2193 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYjVLUHZqcmxzcW9ZbTd3M1M1M3RMVUNVV1ZtMHFuTUFzSzJYNncwWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746089837),('JgtulB8nxXuHrnVswwKOOpqLTLmM06zIo4TPqeXO',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWmR3b0FtaWFlb2txTW9pOGpJa2VaekFPN2R1TXRYRWIyNzFTc2g4VCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746057193),('JprA8HyrK99sM5Mt4QkE9j4Xg0FiXeohqMHnjJEF',NULL,'154.83.103.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWUljTzY2Wmc4SHBBWjZ0M1R6ZzhSMXdTMWppOExMUlpZTEo5QlJ4ayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745969333),('KrkdptnAtZBqKGHUwjMUoMvlT6ZrFDamPF5BF8LL',NULL,'185.247.137.229','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoicGtEM1ZHTmZvMFZhTDZ5S04zUXgyb1QwU0dyalRZb0JYOWpBcmc1VSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746021558),('KTArBbOkfnWQliZ7pZPQC4a57SQZ0eJiUZOKzdiB',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOFlsWWFQUVp4enJObW5reWVaQkVJSzZBRWdZRHl2clVqNlJ6NGgwTCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746061423),('ll8iDP6LtD1slsJOriQb2hwF7Qgon97rhcCPPWHB',NULL,'185.247.137.17','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoib1dYMkhraVFxNm1uSFdYSGN1SXZWWnJhRE5hNzVJcFAyQnl4UzJyOCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746054852),('MooEKDwRj9z9bMIFFZ2TV0xhAvFVmxYppTwlSeub',NULL,'209.126.83.235','Mozilla/5.0 (ZZ; Linux i686; rv:123.0) Gecko/20100101 Firefox/123.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUTdjbnoxWmtHcXZIZnByWWZzbWdrdGhPQkdKNEtINk9GTnpxVnVXciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745988688),('MphyzDBHhFWUvbOtEvNDxLolYteKcZC0aMuhYrF5',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZWtPSFVSelZDbWVpVndycWk3RVNDZDlOZzRjOVE0bUxLOXQ1ZnZVdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746066489),('MqOCcRIZbz1WOMYnvYRrHsEthQzNbPM843n8uowH',NULL,'43.240.223.15','Custom-AsyncHttpClient','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRENJcW5SWWFtemhYbllham9kYjBPVmtkM3FzNEJjTG9FNWlENHd2MyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6ODg6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2luZGV4LnBocD9sYW5nPS4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkZ0bXAlMkZpbmRleDEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1746085934),('N6s9HTdOzQ4ZnG8mCJhOcprtWj38gh1cYY1Kxo56',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZGdsN3dxcG1mb1lvdWJ0bU80a3ROTUZvVTh1ME84S1k5UEt1RUFsQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746066490),('na2qoyFlHtXbOzoxgDAV3jeNxvWlrEy7eF5NL7ok',NULL,'8.209.96.179','Go-http-client/1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZjM4MWpnRUs3UGhNUVBvcTRIU2VaNVppUFMzczZxNnlTamhpbW11TCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjU6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Lz9kbnM9dUUwQkFBQUJBQUFBQUFBQUIyVjRZVzF3YkdVRFkyOXRBQUFCQUFFIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745991679),('Ni42esKJlhXy5mZ6CoLz2t6rXhtz63hOwzCTG2q2',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUEl1ZDJYVmpLZk1nNGcxYjRxajdXUmtNdlU1NkR0Unp0TU43Q2M3QSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746065462),('NkTi8Iz7hMszstTPTWzkSq9NxynSFFvTiLNkRE5p',NULL,'8.209.96.179','Go-http-client/1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoidmM0UjcyYlpkWnNBUGZ0bmh1SkJTQjJ0amtDV3B5ZnF2elc3TmNuYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Lz9uYW1lPWV4YW1wbGUuY29tJnR5cGU9QSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1745991681),('nlTq0P6yEnT8BqBajSSmGJeRMkSbukelIanjLPah',NULL,'64.62.197.170','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOGpDWmVzS0V4Q2hUYWk1QXg2VkY5cm1DZjFRSXV6Qm5ZWVNrdGEyZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746059524),('octrrJxAei4m5wxLgPQrJ71zVCBTy1mGkIcFZT1b',NULL,'43.163.232.152','Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzh3eFVDR0N3cVdPeEd1VFpJS2JhdUwwTkRrbG50QlZuQVR5c0hwdCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746009868),('OQbhnuRFypIiOwFDVgScONAfJrgLbInTgzoCrPyn',NULL,'172.105.80.201','Mozilla/5.0 zgrab/0.x','YTozOntzOjY6Il90b2tlbiI7czo0MDoieFRMbGVBOTJ5M0VoQmVlS3lXazJnaWl6WHJTbHdoa0pWSUpLZ3NDNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745956420),('pPtDCoT27VSWIn1H2g9ebJaew0KIJvqgzE2jnyLc',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaFhSczNTTThZT2kyRHFIc3U3UWw3QXZ5ckNKTG1DSm45b0dkbnNZMyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746065463),('qgBouxCM9FBfkShu9Nz4dye7tWhIY9dHxSDwH6xj',NULL,'24.199.108.76','Mozilla/5.0 (compatible)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNGhudFJKZ2RVRlM4cWtqaHNGa1ZJN0NWMjhKR054a0FMdE5aMFNiSSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vcmVjb20ucHJhc2hhbnQtZGV2b3BzLm9ubGluZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746019234),('siIFx5h66hH13BUHdKasCngGhQvxbwGxtppo32Rd',NULL,'24.199.108.76','Mozilla/5.0 (compatible)','YTozOntzOjY6Il90b2tlbiI7czo0MDoianBSNWZtVXozaXlkRFU4Y3VQT0tOc0JLdU9KcFI2aFZKOHFBR1NISyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDI6Imh0dHBzOi8vcmVjb20ucHJhc2hhbnQtZGV2b3BzLm9ubGluZS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746019236),('slHvRptcqlivkBD71wJFmticxLVirxTtVkgEI8xf',NULL,'101.36.108.158','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/568.50 (KHTML, like Gecko) Chrome/105.0.1016 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUd4MW5FRnRTUGpPamdickRnZzRDNGJBRXlUbEhNMjBUd1FwZDQxVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746089833),('SOxX0RlsarqpZ8Ojbd1BH8wRQlkGDW3R3CBwzVqS',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiODliNzNGc0JWYkY3WnlmdWl5amRFdTdFVTlFdEJFY0dOZFZJTDJ0ZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746052674),('sXxgNqtIKVbEdW5nWbXMVAVLIWhjbRTXGWUChsyq',NULL,'35.82.31.94','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6; rv:57.0) Gecko/20100101 Firefox/57.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiN0NGaG1Obmc3MGJ2cW15SkRtVHBiUTA3YW9NdTJIMHNMRlhLTDBsUCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746047345),('TOYAsJXriY7owHhqWEJ3agSHQW88iBbZ09f3FHrb',NULL,'154.83.103.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoidURzUU5yMUhTOXBhM2VrMjlsUkV0ek9yOG9GRDd5bUxlN0Vqa3pDQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745969333),('uPgNyOtuDHWArEDQCUXK3z6d4ycAZfHcqEptxg5h',NULL,'209.126.83.235','Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiblJYNW92dDNmclY2N2VvRk81NkFaSHI1UlBad0RYYnE4YVpEUFJIRyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746045031),('vB34UyRiKeZ5yfJlEtabivcXehtnfNmQJ2oq6gb6',NULL,'64.62.197.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRmJMYXdlT2NTVkVnWDZzOU5md2kzVHM2aW45Tm5NUXZrRmU5TXd3eSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746059896),('WXnGP4hlqXihYfLmdp6WDBlFLUnyOhhFsvNUyROA',NULL,'35.82.31.94','Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.16) Gecko/20080716 (Gentoo) Galeon/2.0.6','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWDVQUktVc2xoNlZCMDhwM3o2d2xPUGpJSVBqbUlnczN3MDhJVG94aCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746056929),('XenhjrF2OChM94DKYGdIWso55PRnCv07kRm3G67g',NULL,'35.82.31.94','Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/540.0 (KHTML, like Gecko) Ubuntu/10.10 Chrome/9.1.0.0 Safari/540.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZXdCTVhjanZkeFVjcTV1YXlmcnd3ZkpmTHNlcXRwSFFQUmliSFNkRSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746023810),('XRg94DVfgk6g8RnjxHzyALspWQZYUzfWJRSgU5kc',NULL,'46.105.81.71','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiclBSRm5zNUk2UVlsMnlWQU9xT1dQT3htN043WkNka3FLN2gyVU1zMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746060905),('xV8H2PZYKTG0x6RxwVYW9jw677oVzH7j3oj4PqR2',NULL,'198.235.24.54','Expanse, a Palo Alto Networks company, searches across the global IPv4 space multiple times per day to identify customers&#39; presences on the Internet. If you would like to be excluded from our scans, please send IP addresses/domains to: scaninfo@paloaltonetworks.com','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYkM0bExqS3lRVk04RFlDQVFsSnpNQXVST0k5bWdmSUhINHIyZ2F4YiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745946281),('yFTKSk6q2Eqq1dWf6RPXBWg8a3FIOx7YR808tUt8',NULL,'185.247.137.17','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTlZHTExidGFaR2ZFWVBSNTh4VmtjNmE5aUQyZm9mOEcxWThFUWNaYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746054853),('ySK1kf5f6PtGiL198OzXcVOF2rh1T7yZM35gHgj7',NULL,'44.220.185.155','Mozilla/5.0 (Windows NT 6.2;en-US) AppleWebKit/537.32.36 (KHTML, live Gecko) Chrome/54.0.3080.74 Safari/537.32','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSEowV1VNYjg4eWVKbTBPVjNnYmMwU2hRN1dOWWZ0Zk9NY3hiYjNSVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746006132),('zNhSl7Q4inSu6USMhJtzIcQdbFchGeBfVUlnIBZD',NULL,'206.168.34.88','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoibFMxTkpaOHJIRmZXVjBUb3NWWEowMG84U1F2d1Brdkl1RnJYNk5zTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1745994742),('ZrhIaNBr2uGme8uZc0V9fKZsOF9c14Bh7l3FvdRO',NULL,'167.94.138.203','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYUhSZUlDYzZGemZVdkoydDNRYzQxV1J4RUV0S2RMY1JBaWFCTHpaZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHBzOi8vZWMyLTMtMjMxLTU2LTE0Ny5jb21wdXRlLTEuYW1hem9uYXdzLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1745972844),('zsnloWF5HogMKNiNrGdtCKpMyNzXRRTeyJZUHfFW',NULL,'92.255.57.58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZHhtNHNWWEhvbnk2NEZ1WnB1YkJMcDdBS09pQmlQSFNRY0FsWU9GYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746052673),('zStlCLl0XSx3QPRFezJgJI3ERcBm25vCERVcj3ua',NULL,'43.240.223.15','Custom-AsyncHttpClient','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVGI2d1dQVmtSZGdVZElzREVIcEIzM1B3VG9Za1ZFc2RqVFpSOTdFMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTQ2OiJodHRwczovLzMuMjMxLjU2LjE0Ny9pbmRleC5waHA/ZnVuY3Rpb249Y2FsbF91c2VyX2Z1bmNfYXJyYXkmcz0lMkZpbmRleCUyRiU1Q3RoaW5rJTVDYXBwJTJGaW52b2tlZnVuY3Rpb24mdmFycyU1QjAlNUQ9bWQ1JnZhcnMlNUIxJTVEJTVCMCU1RD1IZWxsbyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1746085927),('zuWHgTEQvqibGi4waSoByie44lzmL71pgHCt9bzO',NULL,'206.168.34.210','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVDJwdzJzcWE3V0xOWkZUOHVSd0lVY0xWbko0cnE5SjJRV3ptM29iRSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vMy4yMzEuNTYuMTQ3L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1746069830);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transparency_gtin_code_histories`
--

DROP TABLE IF EXISTS `transparency_gtin_code_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transparency_gtin_code_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `transparency_product_id` bigint unsigned NOT NULL,
  `job_id` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number_of_code` smallint unsigned DEFAULT NULL,
  `gtin` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fnsku` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label_type` tinyint unsigned DEFAULT NULL,
  `generated_code` longtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0-Pending, 1-In Progress, 2-Success, 3-Error',
  `error` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `updated_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transparency_gtin_code_histories_job_id_unique` (`job_id`),
  UNIQUE KEY `transparency_gtin_code_histories_location_unique` (`location`),
  KEY `transparency_gtin_code_histories_transparency_product_id_foreign` (`transparency_product_id`),
  KEY `transparency_gtin_code_histories_created_by_foreign` (`created_by`),
  KEY `transparency_gtin_code_histories_updated_by_foreign` (`updated_by`),
  CONSTRAINT `transparency_gtin_code_histories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `transparency_gtin_code_histories_transparency_product_id_foreign` FOREIGN KEY (`transparency_product_id`) REFERENCES `product_lists` (`id`),
  CONSTRAINT `transparency_gtin_code_histories_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transparency_gtin_code_histories`
--

LOCK TABLES `transparency_gtin_code_histories` WRITE;
/*!40000 ALTER TABLE `transparency_gtin_code_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `transparency_gtin_code_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transparency_product_files`
--

DROP TABLE IF EXISTS `transparency_product_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transparency_product_files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `account_config_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `processing_status` tinyint unsigned NOT NULL DEFAULT '0',
  `error_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transparency_product_files_account_config_id_foreign` (`account_config_id`),
  KEY `transparency_product_files_user_id_foreign` (`user_id`),
  CONSTRAINT `transparency_product_files_account_config_id_foreign` FOREIGN KEY (`account_config_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `transparency_product_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transparency_product_files`
--

LOCK TABLES `transparency_product_files` WRITE;
/*!40000 ALTER TABLE `transparency_product_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `transparency_product_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-01 10:18:41
